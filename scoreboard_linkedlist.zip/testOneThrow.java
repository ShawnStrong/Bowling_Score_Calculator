package scoreboard_linkedlist;

import static org.junit.Assert.*;

import org.junit.Test;

public class testOneThrow {
	scoreboard game = new scoreboard();
	@Test
	public void testOne() {
		game.add(9);
		assertTrue(game.total() == 9);
	}
	@Test
	public void testTwoThrows(){
		game.add(1);
		game.add(3);
		assertTrue(game.total() == 4);
	}
	@Test
	public void testThreeThrows(){
		game.add(1);
		game.add(3);
		game.add(4);
		assertTrue(game.total() == 8);
	}
	@Test
	public void testSpareCountsNextFrameScore(){
		game.add(2);
		game.add(4);
		game.add(7);
		game.add(3);
		game.add(2);
		game.add(1);
		assertTrue(game.total() == 21);
	}
	@Test
	public void testStrikeMovesToNextFrame(){
		game.add(10);
		game.add(3);
		game.add(4);
		assertTrue(game.total() == 24);
		
	}
	@Test
	public void testStrikeCountsNextFrameScores(){
		game.add(10);
		game.add(10);
		game.add(10);
		assertTrue(game.total() == 30);
	}
	@Test
	public void testSpareOnLastFrame(){
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2); // 27
		game.add(4);
		game.add(6);
		game.add(8);
		assertTrue(game.total() == 45);
	}
	@Test
	public void testStrikeOnLastFrames(){
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);		// 21
		assertTrue(game.total() == 21);
		game.add(10);		// 30	8th
		game.add(10);		// 26	9th
		game.add(10);		// 24	10th
		assertTrue(game.total() == 51);
		game.add(6);		// 6
		game.add(4);		// 8
		assertTrue(game.total() == 97);
	}
	@Test
	public void testThrowOn11thFrame(){
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);
		game.add(1);
		game.add(2);		// 21
		assertTrue(game.total() == 21);
		game.add(10);		// 30	8th
		game.add(10);		// 26	9th
		game.add(10);		// 24	10th
		assertTrue(game.total() == 51);
		game.add(6);		// 6
		game.add(4);		// 8
		assertTrue(game.total() == 97);
		try {
			game.add(5);
			assertFalse("Too many throws",true);
		} catch (RuntimeException ex) {
			assertTrue("wrong type of exception: " + ex, ex instanceof IllegalArgumentException);
		}
	}
}
