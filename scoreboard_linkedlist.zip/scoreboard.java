package scoreboard_linkedlist;

import java.util.*;

class Frame {
	int throw_1;
	int throw_2;
	int throw_3;
	boolean strike, spare;

	public Frame() {
		this.throw_1 = -1;
		this.throw_2 = -1;
		this.throw_3 = -1;
		this.strike = false;
		this.spare = false;
	}
}

public class scoreboard {
	List<Frame> list;
	int frames;

	public scoreboard() {
		this.list = new LinkedList<Frame>();
		this.list.add(new Frame());
		this.frames = 0;

	}

	public void add(int threw) {
		if (frames < 9) {
			if (list.get(frames).throw_1 == -1) {
				if (threw == 10) {
					list.get(frames).throw_1 = threw;
					list.get(frames).strike = true;
					list.add(new Frame());
					frames++;
				} else {
					list.get(frames).throw_1 = threw;
				}
			} else {
				list.get(frames).throw_2 = threw;
				if (list.get(frames).throw_1 + list.get(frames).throw_2 == 10) {
					list.get(frames).spare = true;
				}
				list.add(new Frame());
				frames++;
			}
		} else if (frames == 9) {
			// error block to handle too many throws
			if(list.get(frames).throw_1 + list.get(frames).throw_2 < 10){
				if(list.get(frames).throw_2 != -1){
					throw new IllegalArgumentException("Too many throws");
				}
			}
			if(list.get(frames).throw_3 != -1){
				throw new IllegalArgumentException("Too many throws");
			}
			// input throw if past error block
			if (list.get(frames).throw_1 == -1) {
				if (threw == 10) {
					list.get(frames).strike = true;
				}
				list.get(frames).throw_1 = threw;
			} else if (list.get(frames).throw_2 == -1) {
				if (threw == 10) {
					list.get(frames).spare = true;
				}
				list.get(frames).throw_2 = threw;
				if (list.get(frames).throw_1 + list.get(frames).throw_2 == 10) {
					list.get(frames).spare = true;
				}
			} else if (list.get(frames).strike || list.get(frames).spare) {
				list.get(frames).throw_3 = threw;
			}
			
		}
	}

	// NOTE: spares and strikes aren't counted if there aren't enough throws
	// after
	public int total() {
		int sum = 0;
		int trace = 0;
		for (Frame e : list) {
			if (trace == 9) {
				if (e.strike) {
					if (e.throw_2 != -1 && e.throw_3 != -1) {
						sum += 10;
						sum += e.throw_2;	// Count second and third throws just once
						sum += e.throw_3;
					}
				}
				if (e.spare) {
					if (e.throw_3 != -1) {
						sum += 10;			// count third throw just once
						sum += e.throw_3;
					}
				}
				if (!e.strike && !e.spare) {
					if (e.throw_1 != -1) {
						sum += e.throw_1;
					}
					if (e.throw_2 != -1) {
						sum += e.throw_2;
					}
				}
			} else {
				if (e.spare) {
					if (trace < frames) {
						int next = trace + 1;
						sum += 10;
						sum += list.get(next).throw_1;
					}
					// else{
					// sum += 10;
					// }
				} else if (e.strike) {
					int next = trace + 1;
					// if strike frame less than max AND next frame isn't strike
					// frame
					if (trace < frames && !list.get(next).strike && list.get(next).throw_1 != -1) {
						sum += 10;
						sum += list.get(next).throw_1;
						sum += list.get(next).throw_2;
					}
					// if strike frame less than max - 1 AND next two are
					// strikes
					else if (trace < frames - 1 && list.get(next).strike && list.get(next + 1).strike) {
						sum += 30;
					}
					// if strike frame is on 9th frame and there's a 10th frame
					else if (trace < frames && trace == 8 && list.get(next).throw_2 != -1) {
						sum += 10;
						sum += list.get(next).throw_1;
						sum += list.get(next).throw_2;
					}
				} else {
					if (e.throw_1 != -1) {
						sum += e.throw_1;
					}
					if (e.throw_2 != -1) {
						sum += e.throw_2;
					}
				}
				trace++;
			}
		}

		return sum;
	}
}
